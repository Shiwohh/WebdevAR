// Global state
let isAdminMode = false;
let currentEditTarget = null;

// Pre-order notifications functionality
let preOrderNotifications = JSON.parse(localStorage.getItem('preOrderNotifications')) || [];

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    updateNotificationBadge();
    initializeEventListeners();
    
    // Restore admin mode if flag is set
    if (localStorage.getItem('isAdminMode') === 'true') {
        switchToAdminMode();
    } else {
        setGuestMode();
    }
});

// Authentication handlers
function handleAuthClick() {
    if (isAdminMode) {
        toggleAdminDropdown();
    } else {
        showLoginModal();
    }
}

function showLoginModal() {
    const loginModal = document.getElementById('loginModalOverlay');
    if (loginModal) {
        loginModal.classList.add('active');
    }
}

function hideLoginModal() {
    const loginModal = document.getElementById('loginModalOverlay');
    if (loginModal) {
        loginModal.classList.remove('active');
    }
}

function toggleAdminDropdown() {
    const dropdown = document.getElementById('adminDropdown');
    if (dropdown) {
        dropdown.classList.toggle('active');
    }
}

function switchToAdminMode() {
    isAdminMode = true;
    localStorage.setItem('isAdminMode', 'true'); // Persist admin mode
    const authButton = document.getElementById('authButtonText');
    const preOrdersNav = document.getElementById('preOrdersNav');
    const adminButtons = document.querySelectorAll('.admin-buttons');
    const editButtons = document.querySelectorAll('.edit-content-btn');
    
    if (authButton) authButton.textContent = 'Admin View';
    if (preOrdersNav) preOrdersNav.style.display = 'block';
    
    // Add admin-mode class to body to hide guest-only elements
    document.body.classList.add('admin-mode');
    
    // Show admin buttons on product cards
    adminButtons.forEach(btn => btn.style.display = 'flex');
    
    // Show edit buttons on content pages
    editButtons.forEach(btn => btn.style.display = 'block');
    
    hideLoginModal();
    hideAdminDropdown();
}

function switchToGuestMode() {
    isAdminMode = false;
    localStorage.removeItem('isAdminMode'); // Remove admin mode flag
    const authButton = document.getElementById('authButtonText');
    const preOrdersNav = document.getElementById('preOrdersNav');
    const adminButtons = document.querySelectorAll('.admin-buttons');
    const editButtons = document.querySelectorAll('.edit-content-btn');
    
    if (authButton) authButton.textContent = 'Admin Mode';
    if (preOrdersNav) preOrdersNav.style.display = 'none';
    
    // Remove admin-mode class to show guest-only elements
    document.body.classList.remove('admin-mode');
    
    // Hide admin buttons
    adminButtons.forEach(btn => btn.style.display = 'none');
    editButtons.forEach(btn => btn.style.display = 'none');
    
    hideAdminDropdown();
    
    // Redirect from preorders page if currently there
    if (window.location.pathname.includes('preorders.html')) {
        window.location.href = 'index.html';
    }
}

function setGuestMode() {
    isAdminMode = false;
    localStorage.removeItem('isAdminMode'); // Remove admin mode flag
    const authButton = document.getElementById('authButtonText');
    const preOrdersNav = document.getElementById('preOrdersNav');
    const adminButtons = document.querySelectorAll('.admin-buttons');
    const editButtons = document.querySelectorAll('.edit-content-btn');
    
    if (authButton) authButton.textContent = 'Admin Mode';
    if (preOrdersNav) preOrdersNav.style.display = 'none';
    
    // Ensure admin-mode class is removed
    document.body.classList.remove('admin-mode');
    
    adminButtons.forEach(btn => btn.style.display = 'none');
    editButtons.forEach(btn => btn.style.display = 'none');
}

function hideAdminDropdown() {
    const dropdown = document.getElementById('adminDropdown');
    if (dropdown) {
        dropdown.classList.remove('active');
    }
}

// Content editing functionality
function openEditModal(contentType) {
    if (!isAdminMode) return;
    
    currentEditTarget = contentType;
    
    // Create edit modal
    const modalHTML = `
        <div class="edit-modal-overlay active" id="editModalOverlay">
            <div class="edit-modal">
                <div class="edit-modal-header">
                    <h3>Edit ${contentType.charAt(0).toUpperCase() + contentType.slice(1)} Content</h3>
                    <button class="close-edit-modal" onclick="closeEditModal()">&times;</button>
                </div>
                <div class="edit-modal-content">
                    <textarea id="editTextarea" placeholder="Enter content here...">${getContentForEdit(contentType)}</textarea>
                    <div class="edit-modal-actions">
                        <button class="save-edit-btn" onclick="saveEditedContent()">Save Changes</button>
                        <button class="cancel-edit-btn" onclick="closeEditModal()">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    const existingModal = document.getElementById('editModalOverlay');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add new modal
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function getContentForEdit(contentType) {
    const contentElement = document.getElementById(contentType + 'Content');
    if (contentElement) {
        return contentElement.innerText.trim();
    }
    return '';
}

function saveEditedContent() {
    if (!currentEditTarget) return;
    
    const textarea = document.getElementById('editTextarea');
    const content = textarea.value;
    const contentElement = document.getElementById(currentEditTarget + 'Content');
    
    if (contentElement) {
        // Convert plain text to HTML with basic formatting
        const formattedContent = content
            .split('\n\n')
            .map(paragraph => `<p class="${currentEditTarget}-description">${paragraph.trim()}</p>`)
            .join('');
        
        contentElement.innerHTML = formattedContent;
    }
    
    closeEditModal();
}

function closeEditModal() {
    const modal = document.getElementById('editModalOverlay');
    if (modal) {
        modal.remove();
    }
    currentEditTarget = null;
}

// Frame Edit Modal functionality
function openFrameEditModal(editButton) {
    if (!isAdminMode) return;
    
    const productCard = editButton.closest('.product-card');
    const productTitle = productCard.querySelector('.product-title').textContent;
    const productPrice = productCard.querySelector('.product-price').textContent;
    
    const modal = document.getElementById('frameEditModalOverlay');
    const nameInput = document.getElementById('frameNameInput');
    const priceInput = document.getElementById('framePriceInput');
    const statusInput = document.getElementById('frameStatusInput');
    
    // Populate the form with current values
    if (nameInput) nameInput.value = productTitle;
    if (priceInput) priceInput.value = productPrice;
    if (statusInput) statusInput.value = 'Available';
    
    // Store reference to the product card being edited
    modal.dataset.editingCard = productCard.dataset.cardIndex || Array.from(document.querySelectorAll('.product-card')).indexOf(productCard);
    
    if (modal) {
        modal.classList.add('active');
        modal.style.display = 'flex';
    }
}

function closeFrameEditModal() {
    const modal = document.getElementById('frameEditModalOverlay');
    if (modal) {
        modal.classList.remove('active');
        modal.style.display = 'none';
        modal.removeAttribute('data-editing-card');
    }
}

function saveFrameEdit() {
    const modal = document.getElementById('frameEditModalOverlay');
    const nameInput = document.getElementById('frameNameInput');
    const priceInput = document.getElementById('framePriceInput');
    const statusInput = document.getElementById('frameStatusInput');
    
    const cardIndex = modal.dataset.editingCard;
    if (cardIndex !== undefined) {
        const productCards = document.querySelectorAll('.product-card');
        const targetCard = productCards[parseInt(cardIndex)];
        
        if (targetCard) {
            const titleElement = targetCard.querySelector('.product-title');
            const priceElement = targetCard.querySelector('.product-price');
            
            if (titleElement && nameInput.value) {
                titleElement.textContent = nameInput.value;
            }
            if (priceElement && priceInput.value) {
                priceElement.textContent = priceInput.value;
            }
        }
    }
    
    closeFrameEditModal();
}

// Sidebar functions
function toggleSidebar() {
    const sidebar = document.getElementById('frameSidebar');
    const mainContent = document.getElementById('mainContent');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (sidebar) sidebar.classList.toggle('active');
    if (mainContent) mainContent.classList.toggle('shifted');
    if (overlay) overlay.classList.toggle('active');
}

function closeSidebar() {
    const sidebar = document.getElementById('frameSidebar');
    const mainContent = document.getElementById('mainContent');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (sidebar) sidebar.classList.remove('active');
    if (mainContent) mainContent.classList.remove('shifted');
    if (overlay) overlay.classList.remove('active');
}

// Frame category selection
function selectFrameCategory(category) {
    const frameTypeTitle = document.getElementById('frameTypeTitle');
    if (frameTypeTitle) {
        frameTypeTitle.textContent = category;
    }
    closeSidebar();
    filterProductsByCategory(category);
}

function filterProductsByCategory(category) {
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.style.display = 'block';
    });
}

// Notifications functionality
function toggleNotifications() {
    const panel = document.getElementById('notificationsPanel');
    if (panel) {
        panel.classList.toggle('active');
        updateNotificationsList();
    }
}

function hideNotifications() {
    const panel = document.getElementById('notificationsPanel');
    if (panel) {
        panel.classList.remove('active');
    }
}

function addPreOrderNotification(frameName, customerName, orderDetails) {
    const notification = {
        id: Date.now(),
        frameName: frameName || 'Titanium Slim Frame',
        customerName: customerName || 'Customer',
        message: `Pre-order confirmed for "${frameName || 'Titanium Slim Frame'}". We'll contact you when available.`,
        confirmationDetails: `Thank you for your interest in the "${frameName || 'Titanium Slim Frame'}". We've received your pre-order request. Our team will contact you once the item becomes available.`,
        timestamp: new Date().toISOString(),
        status: 'confirmed'
    };
    
    preOrderNotifications.unshift(notification);
    localStorage.setItem('preOrderNotifications', JSON.stringify(preOrderNotifications));
    updateNotificationBadge();
    updateNotificationsList();
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationBadge');
    const count = preOrderNotifications.length;
    
    if (badge) {
        badge.textContent = count;
        if (count === 0) {
            badge.classList.add('hidden');
        } else {
            badge.classList.remove('hidden');
        }
    }
}

function updateNotificationsList() {
    const list = document.getElementById('notificationsList');
    if (!list) return;
    
    if (preOrderNotifications.length === 0) {
        list.innerHTML = '<div class="empty-notifications"><p>No pre-orders yet</p></div>';
        return;
    }
    
    list.innerHTML = preOrderNotifications.map(notification => `
        <div class="notification-item" onclick="showNotificationDetails('${notification.id}')">
            <div class="notification-title">${notification.frameName}</div>
            <div class="notification-message">${notification.message}</div>
            <div class="notification-time">${formatNotificationTime(notification.timestamp)}</div>
        </div>
    `).join('');
}

function showNotificationDetails(notificationId) {
    const notification = preOrderNotifications.find(n => n.id === parseInt(notificationId));
    if (notification) {
        hideNotifications();
        showConfirmationModal(notification);
    }
}

function showConfirmationModal(notification) {
    const overlay = document.createElement('div');
    overlay.className = 'confirmation-modal-overlay';
    overlay.onclick = hideConfirmationModal;
    
    overlay.innerHTML = `
        <div class="confirmation-modal" onclick="event.stopPropagation()">
            <div class="confirmation-modal-header">
                <h3>Pre-Order Confirmation</h3>
                <span class="close-confirmation" onclick="hideConfirmationModal()">×</span>
            </div>
            <div class="confirmation-modal-content">
                <h4>${notification.frameName}</h4>
                <p>${notification.confirmationDetails}</p>
                <div class="confirmation-modal-time">
                    Ordered on ${formatDetailedTime(notification.timestamp)}
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(overlay);
    setTimeout(() => overlay.classList.add('active'), 10);
}

function hideConfirmationModal() {
    const modal = document.querySelector('.confirmation-modal-overlay');
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => modal.remove(), 300);
    }
}

function formatNotificationTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now - date) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
}

function formatDetailedTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

// Password toggle function
function togglePassword() {
    const passwordInput = document.getElementById('passwordInput');
    const passwordToggle = document.querySelector('.password-toggle');
    
    if (passwordInput && passwordToggle) {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            passwordToggle.textContent = '🙈';
        } else {
            passwordInput.type = 'password';
            passwordToggle.textContent = '👁';
        }
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('frameSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(event) {
            const searchTerm = event.target.value.toLowerCase();
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const productTitle = card.querySelector('.product-title');
                if (productTitle) {
                    const productName = productTitle.textContent.toLowerCase();
                    if (productName.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    }
}

// Event listeners initialization
function initializeEventListeners() {
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.auth-section')) {
            hideAdminDropdown();
        }
        
        if (!event.target.closest('.sidebar') && !event.target.closest('.frame-types-menu')) {
            closeSidebar();
        }
        
        if (!event.target.closest('.notifications-panel') && !event.target.closest('.notification-wrapper')) {
            hideNotifications();
        }
    });

    // Handle login form submission
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            switchToAdminMode();
        });
    }

    // Handle pre-order form submission if on preorder page
    const preorderPageForm = document.querySelector('.preorder-page-form');
    if (preorderPageForm) {
        preorderPageForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(preorderPageForm);
            const firstName = formData.get('firstName') || preorderPageForm.querySelector('input[placeholder="First Name"]')?.value || '';
            const lastName = formData.get('lastName') || preorderPageForm.querySelector('input[placeholder="Last Name"]')?.value || '';
            const customerName = `${firstName} ${lastName}`.trim() || 'Customer';
            
            addPreOrderNotification('Titanium Slim Frame', customerName);
            window.location.href = 'preorder-confirmation.html';
        });
    }

    // Admin button handlers
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('edit-btn')) {
            openFrameEditModal(event.target);
        } else if (event.target.classList.contains('delete-btn')) {
            if (confirm('Are you sure you want to delete this product?')) {
                console.log('Delete product confirmed');
            }
        } else if (event.target.classList.contains('visible-btn')) {
            const button = event.target;
            if (button.textContent === 'Visible') {
                button.textContent = 'Hidden';
                button.style.background = '#666';
            } else {
                button.textContent = 'Visible';
                button.style.background = '#540000';
            }
        }
    });

    // Initialize search
    initializeSearch();
}

// Utility functions
function navigateToHome() {
    window.location.href = 'index.html';
}

// Admin functions for future expansion
function enableAdminMode() {
    switchToAdminMode();
}

function updateFrameDetails(frameId, details) {
    console.log('Updating frame:', frameId, details);
}